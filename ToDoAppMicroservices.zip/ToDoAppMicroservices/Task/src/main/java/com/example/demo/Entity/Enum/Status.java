package com.example.demo.Entity.Enum;

public enum Status {
    TO_DO,
    IN_PROGRESS,
    DONE
}
