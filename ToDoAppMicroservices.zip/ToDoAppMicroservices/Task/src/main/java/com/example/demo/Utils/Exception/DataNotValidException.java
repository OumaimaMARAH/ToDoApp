package com.example.demo.Utils.Exception;

public class DataNotValidException extends Exception{
    public DataNotValidException(String str){
        super(str);
    }
}
