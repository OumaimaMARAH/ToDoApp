package com.example.demo.Utils.Exception;

public class DataNotValidException extends Exception{
    public DataNotValidException(String message){
        super(message);
    }
}
